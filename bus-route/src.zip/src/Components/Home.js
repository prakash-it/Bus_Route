import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'


import image6 from '../img6.jpg'



import '../index.css'
import '../Components/Home.css'

import { Link, Outlet, Navigate } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
// import Login from './Login'
export default function Home(props) {
  const navigate = useNavigate()
  const handleClick = (props) => {
    console.log("button click");
    if (props.islogged) {
        navigate('/Filter');
    } else {
        navigate('/login');
    }
};
  // return (
  //   <div>
  //     {/*=================================== first row ===================================== */}
  //     <div class="row col-lg-12">
  //       <div class="col-sm-3 mb-3 mb-sm-0 cardDiv">
  //         <div class="card">
  //           <img className='myImage' src={image1} alt='busImage'/>
  //           <div class="card-body">
  //             <h5 class="card-title">Point to Point Bus</h5>
  //             <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
  //             <div>
  //                 <nav>
  //                  <button class="btn btn-primary" onClick={handleClick}>Click here</button>
  //                 </nav>
  //               </div>
  // const handleClick = () => {
  //   navigate('/Filter')
    // return()=>{
    //   navigate('/signin')
    // }
  // }
  return (
    <div>
      <h1 className='bus-head'>Route Bus City Transport Portal</h1>
      {/*=================================== Image-card row start===================================== */}
      <div className='buscard'>
        <div class="row col-lg-12">
          <div class="col-sm-3 mb-3 mb-sm-0 cardDiv">
            <div class="card">
              <img className='myImage' src={image6} alt='busImage' />
              <div class="card-body">
                <h5 class="card-title">SETC Buses</h5>
                <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <a href="#" class="baa-baa">Go somewhere</a>
              </div>
            </div>
          </div>
          <div class="col-sm-3">
            <div class="card">
              <img className='myImage' src={image6} alt='busImage' />
              <div class="card-body">
                <h5 class="card-title">SETC Buses</h5>
                <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <a href="#" class="baa-baa">Go somewhere</a>
              </div>
            </div>
          </div>
          <div class="col-sm-3">
            <div class="card">
              <img className='myImage' src={image6} alt='busImage' />
              <div class="card-body">
                <h5 class="card-title">SETC Buses</h5>
                <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <a href="#" class="baa-baa">Go somewhere</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*=================================== Image card row End===================================== */}

      {/*======================================== Banner content start==============================*/}
      <div class='banner-container'>
        <div className='bus-para'>
          <p>
            Welcome to Route Bus City Transport Portal, your comprehensive platform for all things related to city transportation via bus routes. Our portal aims to provide you with seamless access to information about bus routes, schedules, fares, and much more to enhance your urban commuting experience.
          </p>
          <p>
            Whether you're a daily commuter, a tourist exploring the city, or someone seeking alternative transportation options, our portal is designed to cater to your needs. With a user-friendly interface and up-to-date information, navigating through the city's bus network has never been easier.
          </p>
          <p>
            Discover detailed route maps covering all major city destinations, including popular tourist attractions, business districts, and residential areas. Plan your journey in advance by accessing real-time schedules for each bus route, ensuring you reach your destination on time.
          </p>
          <p>
            Our platform also provides valuable information on fares, ticketing options, and payment methods, making it convenient for you to pay for your ride. Stay informed about any service updates, route changes, or special announcements through our notification system, ensuring a smooth and hassle-free commuting experience.
          </p>
          <p>
            Route Bus City Transport Portal is committed to enhancing the overall commuting experience for residents and visitors alike. Join us on this journey towards a more connected and accessible city transportation system. Let's make every bus ride a convenient and enjoyable experience for everyone. Welcome aboard!
          </p>
        </div>
      </div>
      {/*======================================== Banner content End==============================*/}

      {/*======================================== Carousel start===================================*/}

    



    </div>
  )
}

