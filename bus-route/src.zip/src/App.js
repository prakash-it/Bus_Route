
import { Route, Routes } from 'react-router-dom';
import './App.css';
import Home from './Components/Home';
import About from './Components/About';
import Contect from './Components/Contect';
import Navbar from './Components/Navbar';

import Filter from './Components/Filter';
import Admin from './Components/Admin';
import Admintable from './Components/Admintable';

import Signin from './Components/Signin';

import Auth from './Components/Auth';
import Requiredauth from './Components/Requiredauth';
import Login from './Components/Login';



function App() {
  return (
    <div className="App">


    {/* <Navbar/>



      {/* <Navbar/>

 <Routes>
  <Route path='/' element={<Home/>}>
    
  </Route>
  <Route path='/Filter' element={<Filter/>}/>
  <Route path='/about' element={<About/>}/>
  <Route path='/contact' element={<Contect/>}/> 

 </Routes>

 <Admin/>


  <Route  path='/signin' element={<Signin/>}/> 
 </Routes>

 <Signin/> */}


  
  <Admin/>

  
 <Admintable/>



 <Filter/>


    </div>
  );
}

export default App;
